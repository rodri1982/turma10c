package br.com.itau.itaumon.itaumon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItaumonApplicationTests {

	@Test
	void contextLoads() {
	}

}
